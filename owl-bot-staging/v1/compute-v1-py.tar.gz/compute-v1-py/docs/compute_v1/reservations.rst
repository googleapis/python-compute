Reservations
------------------------------

.. automodule:: google.cloud.compute_v1.services.reservations
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.reservations.pagers
    :members:
    :inherited-members:
