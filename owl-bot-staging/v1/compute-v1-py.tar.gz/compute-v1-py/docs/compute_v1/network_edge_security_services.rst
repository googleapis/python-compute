NetworkEdgeSecurityServices
---------------------------------------------

.. automodule:: google.cloud.compute_v1.services.network_edge_security_services
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.network_edge_security_services.pagers
    :members:
    :inherited-members:
