Snapshots
---------------------------

.. automodule:: google.cloud.compute_v1.services.snapshots
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.snapshots.pagers
    :members:
    :inherited-members:
