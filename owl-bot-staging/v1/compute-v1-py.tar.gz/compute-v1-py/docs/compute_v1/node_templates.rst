NodeTemplates
-------------------------------

.. automodule:: google.cloud.compute_v1.services.node_templates
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.node_templates.pagers
    :members:
    :inherited-members:
