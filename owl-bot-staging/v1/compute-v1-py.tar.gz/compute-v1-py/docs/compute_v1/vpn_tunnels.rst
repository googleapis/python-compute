VpnTunnels
----------------------------

.. automodule:: google.cloud.compute_v1.services.vpn_tunnels
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.vpn_tunnels.pagers
    :members:
    :inherited-members:
