InstanceTemplates
-----------------------------------

.. automodule:: google.cloud.compute_v1.services.instance_templates
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.instance_templates.pagers
    :members:
    :inherited-members:
