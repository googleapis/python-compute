GlobalPublicDelegatedPrefixes
-----------------------------------------------

.. automodule:: google.cloud.compute_v1.services.global_public_delegated_prefixes
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.global_public_delegated_prefixes.pagers
    :members:
    :inherited-members:
