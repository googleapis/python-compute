Interconnects
-------------------------------

.. automodule:: google.cloud.compute_v1.services.interconnects
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.interconnects.pagers
    :members:
    :inherited-members:
