TargetVpnGateways
-----------------------------------

.. automodule:: google.cloud.compute_v1.services.target_vpn_gateways
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.target_vpn_gateways.pagers
    :members:
    :inherited-members:
