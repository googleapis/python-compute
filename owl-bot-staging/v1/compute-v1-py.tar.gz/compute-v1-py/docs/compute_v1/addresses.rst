Addresses
---------------------------

.. automodule:: google.cloud.compute_v1.services.addresses
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.addresses.pagers
    :members:
    :inherited-members:
