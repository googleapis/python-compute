Disks
-----------------------

.. automodule:: google.cloud.compute_v1.services.disks
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.disks.pagers
    :members:
    :inherited-members:
