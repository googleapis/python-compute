GlobalForwardingRules
---------------------------------------

.. automodule:: google.cloud.compute_v1.services.global_forwarding_rules
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.global_forwarding_rules.pagers
    :members:
    :inherited-members:
