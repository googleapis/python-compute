LicenseCodes
------------------------------

.. automodule:: google.cloud.compute_v1.services.license_codes
    :members:
    :inherited-members:
