PublicDelegatedPrefixes
-----------------------------------------

.. automodule:: google.cloud.compute_v1.services.public_delegated_prefixes
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.public_delegated_prefixes.pagers
    :members:
    :inherited-members:
