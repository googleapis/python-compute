Routers
-------------------------

.. automodule:: google.cloud.compute_v1.services.routers
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.routers.pagers
    :members:
    :inherited-members:
