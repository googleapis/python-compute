DiskTypes
---------------------------

.. automodule:: google.cloud.compute_v1.services.disk_types
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.disk_types.pagers
    :members:
    :inherited-members:
