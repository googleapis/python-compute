GlobalAddresses
---------------------------------

.. automodule:: google.cloud.compute_v1.services.global_addresses
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.global_addresses.pagers
    :members:
    :inherited-members:
