ServiceAttachments
------------------------------------

.. automodule:: google.cloud.compute_v1.services.service_attachments
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.service_attachments.pagers
    :members:
    :inherited-members:
