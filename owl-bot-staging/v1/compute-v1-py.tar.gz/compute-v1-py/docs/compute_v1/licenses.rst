Licenses
--------------------------

.. automodule:: google.cloud.compute_v1.services.licenses
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.licenses.pagers
    :members:
    :inherited-members:
