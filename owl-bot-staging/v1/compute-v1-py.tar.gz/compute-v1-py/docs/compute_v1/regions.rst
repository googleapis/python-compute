Regions
-------------------------

.. automodule:: google.cloud.compute_v1.services.regions
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.regions.pagers
    :members:
    :inherited-members:
