PublicAdvertisedPrefixes
------------------------------------------

.. automodule:: google.cloud.compute_v1.services.public_advertised_prefixes
    :members:
    :inherited-members:

.. automodule:: google.cloud.compute_v1.services.public_advertised_prefixes.pagers
    :members:
    :inherited-members:
